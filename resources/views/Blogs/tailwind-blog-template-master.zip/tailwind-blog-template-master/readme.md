# Tailwind Blog Template

This is a simple blog template buit with [Tailwind](https://tailwindcss.com/) and [AlpineJS](https://github.com/alpinejs/alpine). Alpine was used for the mobile menu and the basic carousel at the bottom of the page.

View the blog demo [here](https://tailwind-blog-demo.dgrzyb.me) and the post demo [here](https://tailwind-blog-demo.dgrzyb.me/post.html) 😎